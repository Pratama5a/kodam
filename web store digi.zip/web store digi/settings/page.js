const pageData = {
    title: "DIGI STORE",
    description: "Cari Store Termurah? Tentu Ada Di Digi Store",
    profilePic: "https://telegra.ph/file/a0a0674f404ebc4a4836c.jpg",
    socialLinks: {
        facebook: "https://facebook.com",
        instagram: "https://www.instagram.com/adtyapr_1",
        tiktok: "https://www.tiktok.com",
        youtube: "https://youtube.com"
    },
    buttons: [
        { text: "Testimoni", link: "/feature/testi.html" }
    ],
    collectionTitle: "Pricelist",
    artworks: [
        { title: "", image: "https://telegra.ph/file/7cff8e0a10b95eb27d5f4.jpg", description: "PANEL BOT WA", price: "1K/GB" },
        { title: "", image: "https://telegra.ph/file/7cff8e0a10b95eb27d5f4.jpg", description: "PANEL BOT WA UNLI", price: "200k/6bulan" },
        { title: "", image: "https://telegra.ph/file/7cff8e0a10b95eb27d5f4.jpg", description: "PANEL MC", price: "2K/GB" },
        { title: "", image: "https://telegra.ph/file/ca2e0d3e4ab6de4cc9ec2.jpg", description: "NOKOS +62", price: "6.5K" },
        { title: "", image: "https://telegra.ph/file/ca2e0d3e4ab6de4cc9ec2.jpg", description: "NOKOS NEGARA LUAR", price: "TERGANTUNG REGION" }
    ],
    collectionLink: "https://wa.me/6281282692009",
    whatsappNumber: "6281282692009"
};

// Ensure `pageData` is accessible globally
window.pageData = pageData;
